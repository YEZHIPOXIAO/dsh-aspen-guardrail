# Contributing

Run `npm test` and `npm run check` with Node.js 22 or newer. No dependency installation is needed. Use a branch and a pull request with the problem, evidence, compatibility impact and verification steps.

Changes to matching rules require a positive and negative synthetic fixture. State recovery and acceptance changes must test stale artifacts, changed evidence, cross-session isolation and interruption. Do not add real customer models, private conversation logs, local absolute paths, secrets or screenshots containing private information.

Keep engineering rules conditional. A match is a diagnostic candidate, not proof of root cause. Do not convert a single installation failure into a universal Aspen restriction. Do not infer time saved from arbitrary constants.

All contributions are submitted under MIT. Preserve license and attribution notices. Treat contributors respectfully, critique the work rather than the person, and keep review discussion relevant and constructive.

Before a public release, create the repository under the owner's account, set real repository/bugs/homepage metadata, verify packaged contents, run CI and document the supported Harness version. This checkout deliberately has no invented repository URL.
