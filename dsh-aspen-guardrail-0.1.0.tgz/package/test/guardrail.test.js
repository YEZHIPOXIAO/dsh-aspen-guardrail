// SPDX-License-Identifier: MIT
import test from 'node:test';
import assert from 'node:assert/strict';
import { apply } from '../index.js';
import { newState, finish, restore, review, envelope, mutationTarget } from '../src/core.js';
const fp = { key: 'artifact', path: '/work/case.bkp', sha256: 'hash', capturedAt: 10 };
const start = () => newState('s', fp, { intent: 'Fix explicit units', route: 'validated text edit' }, 1);
test('initial file hash is not final verification baseline', () => {
  const result = finish(start(), fp);
  assert.equal(result.closed, false);
  assert.equal(result.missing.length, 5);
});
test('changed delivery artifact and missing level prevent closure', () => {
  const state = start(); state.baseline = fp;
  state.evidence = ['V0', 'V1', 'V2', 'V3'].map(level => ({ level, sha256: fp.sha256, targetKey: fp.key, recordedAt: 11 }));
  assert.equal(finish(state, fp).closed, true);
  assert.equal(finish(state, { ...fp, sha256: 'changed' }).closed, false);
  state.evidence.pop(); assert.equal(finish(state, fp).closed, false);
});
test('checkpoint replay trusts only matched plugin tool and command outputs', () => {
  const text = JSON.stringify(envelope(start(), {}));
  const result = { type: 'tool/result', data: { message: { toolCallId: 'c', content: [{ type: 'text', text }] } } };
  assert.equal(restore([result]), null);
  assert.equal(restore([{ type: 'tool/call', data: { callId: 'c', name: 'read' } }, result]), null);
  assert.equal(restore([{ type: 'tool/call', data: { callId: 'c', name: 'aspen_guardrail' } }, result]).sessionId, 's');
  assert.equal(restore([{ type: 'command/run', data: { commandId: 'q', name: 'aspen-guardrail' } }, { type: 'command/done', data: { commandId: 'q', kind: 'success', text } }]).sessionId, 's');
});
test('review excludes quoted read output and deduplicates call id', () => {
  const events = ['read', 'pwsh'].flatMap((name, i) => [
    { type: 'tool/call', data: { name, callId: String(i) } },
    { type: 'tool/result', seq: i + 1, time: 100, data: { message: { toolCallId: String(i), content: [{ type: 'text', text: 'AE_UNDERSPEC' }] } } }
  ]);
  const report = review([...events, events.at(-1)]);
  assert.equal(report.findings.length, 1); assert.equal(report.findings[0].count, 1);
});
test('gate targets structured Aspen mutations, not generic reads or shell', () => {
  assert.equal(mutationTarget({ name: 'read', arguments: { file_path: 'a.bkp' } }), null);
  assert.equal(mutationTarget({ name: 'write', arguments: { file_path: 'a.BKP' } }), 'a.BKP');
  assert.equal(mutationTarget({ name: 'pwsh', arguments: { command: 'read a.bkp' } }), null);
});
function harness() {
  let tool, command, guard; const effects = []; const events = [];
  const files = new Map([['/work/case.bkp', 'original']]);
  const ctx = {
    tools: { register: t => { tool = t; return () => {}; }, guard: g => { guard = g; return () => {}; } },
    commands: { register: c => { command = c; return () => {}; } },
    effect: fn => effects.push(fn()),
    workingDirectory: { ensure: async () => '/work' },
    sessionQuery: { readSession: async id => ({ session: { id, cwd: '/work' }, events }) },
    fs: {
      resolve: async p => ({ targetKey: p.startsWith('/') ? p : `/work/${p}`, displayPath: p.startsWith('/') ? p : `/work/${p}` }),
      stat: async t => files.has(t.targetKey) ? { type: 'file', version: files.get(t.targetKey) } : undefined,
      readBytes: async t => Buffer.from(files.get(t.targetKey)), readText: async t => files.get(t.targetKey)
    }
  };
  apply(ctx);
  const agent = { id: 's' }; const signal = new AbortController().signal;
  const run = async args => {
    const value = await tool.execute(args, { agent, signal });
    const id = String(events.length);
    events.push({ type: 'tool/call', data: { callId: id, name: tool.name } }, { type: 'tool/result', data: { message: { toolCallId: id, content: tool.output.render(args, value) } } });
    return value;
  };
  return { run, files, guard: () => guard, command: () => command, ctx, agent, signal };
}
test('tool and command share state, enforce evidence, recover after reload', async () => {
  const h = harness();
  assert.match(h.guard()({ name: 'write', arguments: { file_path: '/work/case.bkp' }, agent: h.agent }), /start/);
  await h.run({ action: 'start', target: 'case.bkp', intent: 'Units', route: 'Text on copy' });
  assert.equal(h.guard()({ name: 'edit', arguments: { file_path: '/work/case.bkp' }, agent: h.agent }), undefined);
  h.files.set('/work/case.bkp', 'edited');
  const snapshot = await h.run({ action: 'snapshot' });
  const sha = snapshot.state.baseline.sha256;
  h.files.set('/work/report.txt', `Artifact ${sha}: reviewer report`);
  for (const level of ['V0', 'V1', 'V2', 'V3']) await h.run({ action: 'evidence', level, note: 'Synthetic test attestation', evidencePath: 'report.txt' });
  const reply = await h.command().handler({ agent: h.agent, rawInput: '{"action":"finish"}', signal: h.signal });
  assert.equal(reply.kind, 'success'); assert.equal(JSON.parse(reply.text).result.closed, true);
  assert.match(h.guard()({ name: 'write', arguments: { file_path: '/work/case.bkp' }, agent: h.agent }), /start/);
  apply(h.ctx); const recovered = await h.run({ action: 'check' });
  assert.equal(recovered.state.target.sha256.length, 64);
});
test('finish rejects changed evidence report', async () => {
  const h = harness();
  await h.run({ action: 'start', target: 'case.bkp', intent: 'Units', route: 'Text' });
  const { state } = await h.run({ action: 'snapshot' });
  h.files.set('/work/e.txt', state.baseline.sha256);
  for (const level of ['V0', 'V1', 'V2', 'V3']) await h.run({ action: 'evidence', level, note: 'Synthetic', evidencePath: 'e.txt' });
  h.files.set('/work/e.txt', 'changed');
  assert.equal((await h.run({ action: 'finish' })).result.closed, false);
});
