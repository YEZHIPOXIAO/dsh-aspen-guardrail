# Changelog

## 0.1.0

- Add task contracts through the `aspen_guardrail` tool and `/aspen-guardrail` command.
- Add bounded SHA-256 snapshots, V0–V3 evidence references and stale-report checks.
- Add session-log recovery, scoped structured-write gate and explicit historical review.
- Add eight conditional failure signatures and engineering review checklist.
- Add a bilingual composer help panel, original icon and read-only Python probe.
- Add dependency-free tests, GitHub CI and MIT licensing.

Limitations: no automatic Aspen execution, universal shell interception, semantic engineering certification, live error injection or measured time-savings claims.
