// SPDX-License-Identifier: MIT
import { createHash } from 'node:crypto';
import path from 'node:path';
import { checklist, rules } from './src/rules.js';
import { restore, review, newState, finish, mutationTarget, envelope, resumePacket } from './src/core.js';
export const inject = ['tools', 'fs', 'workingDirectory', 'sessionQuery', 'commands'];
const str = description => ({ type: 'string', description });
export const parameters = {
  type: 'object', additionalProperties: false, required: ['action'], properties: {
    action: { type: 'string', enum: ['start', 'check', 'snapshot', 'evidence', 'finish', 'review', 'rules', 'resume', 'cancel'] },
    target: str('Existing Aspen artifact path; required for start. Relative to the current workspace.'),
    intent: str('Authorized engineering change and success criteria; required for start.'),
    route: str('Chosen editing route and fallback; required for start.'),
    level: { type: 'string', enum: ['V0', 'V1', 'V2', 'V3'], description: 'Evidence level: exact-file reopen, rerun, diagnostic counts, engineering review.' },
    evidencePath: str('Existing UTF-8 evidence file; required for evidence. Its hash is recorded.'),
    note: str('Reviewer attestation, including residual warnings and limitations; required for evidence.'),
    sessionId: str('Only for review: exact historical session to analyze, limited to this workspace.')
  }
};
export function apply(ctx) {
  const cache = new Map();
  const queues = new Map();
  function serial(id, fn) {
    const next = (queues.get(id) ?? Promise.resolve()).catch(() => {}).then(fn);
    queues.set(id, next);
    return next.finally(() => { if (queues.get(id) === next) queues.delete(id); });
  }
  async function fingerprint(targetPath, cwd, signal) {
    const target = await ctx.fs.resolve(targetPath, { cwd, signal });
    const before = await ctx.fs.stat(target, signal);
    if (before?.type !== 'file') throw new Error('Target must be an existing regular file.');
    const bytes = await ctx.fs.readBytes(target, signal, 64 * 1024 * 1024);
    const after = await ctx.fs.stat(target, signal);
    if (!after || before.version !== after.version) throw new Error('File changed during hashing; retry after the writer stops.');
    return { key: target.targetKey, path: target.displayPath, sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length, capturedAt: Date.now() };
  }
  async function operate(args, agent, signal) {
    if (!agent?.id) throw new Error('A session is required.');
    signal?.throwIfAborted();
    if (!args || typeof args !== 'object' || Array.isArray(args)) throw new Error('Expected an argument object.');
    for (const [key, value] of Object.entries(args)) {
      if (!(key in parameters.properties) || typeof value !== 'string' || value.length > 16000) throw new Error(`Invalid or oversized argument: ${key}`);
    }
    if (!parameters.properties.action.enum.includes(args.action)) throw new Error('Unknown action');
    const cwd = await ctx.workingDirectory.ensure(agent, signal);
    if (args.action === 'rules') return { rules, checklist };
    if (args.action === 'review') {
      const source = await ctx.sessionQuery.readSession(args.sessionId ?? agent.id);
      const sourceRoot = await ctx.fs.resolve(source.session.cwd ?? '', { cwd, signal });
      const root = await ctx.fs.resolve(cwd, { signal });
      if (sourceRoot.targetKey !== root.targetKey) throw new Error('Historical review is limited to the current workspace.');
      return { sessionId: source.session.id, ...review(source.events) };
    }
    let state = cache.get(agent.id)?.state;
    if (!state) {
      const log = await ctx.sessionQuery.readSession(agent.id);
      state = restore(log.events);
      if (state?.sessionId !== agent.id) state = null;
    }
    let result;
    if (args.action === 'start') {
      if (state?.status === 'active') throw new Error('An active contract exists. Finish or cancel it before starting another.');
      if (!/\.(bkp|apw|apwz|inp)$/i.test(args.target ?? '')) throw new Error('start requires a BKP/APW/APWZ/INP target.');
      state = newState(agent.id, await fingerprint(args.target, cwd, signal), args);
      result = { next: 'Inspect the checklist, edit a working copy under the authorized scope, then snapshot the final target. No COM capability has been inferred.' };
    } else {
      if (!state) throw new Error('No contract. Use start with target, intent and route.');
      state = structuredClone(state);
      if (args.action === 'check') result = { ...review((await ctx.sessionQuery.readSession(agent.id)).events.filter(e => e.time >= state.createdAt)), next: state.baseline ? 'Collect remaining V0–V3 evidence; finish rechecks evidence and artifact hashes.' : 'snapshot the final edited target before acceptance evidence.' };
      else if (args.action === 'resume') result = { markdown: resumePacket(state) };
      else {
        if (state.status !== 'active') throw new Error('Contract is not active. Start a new contract.');
        if (args.action === 'cancel') { state.status = 'cancelled'; result = { cancelled: true }; }
        else if (args.action === 'snapshot') {
          state.baseline = await fingerprint(state.target.path, cwd, signal);
          state.evidence = [];
          result = { next: 'Reopen and rerun this exact artifact; record evidence V0–V3. Snapshot resets old acceptance evidence.' };
        } else if (args.action === 'evidence') {
          if (!state.baseline) throw new Error('snapshot the final artifact before evidence');
          if (!['V0', 'V1', 'V2', 'V3'].includes(args.level) || !args.note?.trim() || !args.evidencePath) throw new Error('evidence requires level, evidencePath and note');
          const current = await fingerprint(state.target.path, cwd, signal);
          if (current.sha256 !== state.baseline.sha256 || current.key !== state.baseline.key) throw new Error('Artifact changed. Take another snapshot and repeat acceptance checks.');
          const reference = await fingerprint(args.evidencePath, cwd, signal);
          if (reference.key === current.key) throw new Error('Evidence must be a separate report or log, not the artifact itself.');
          const refTarget = await ctx.fs.resolve(args.evidencePath, { cwd, signal });
          if (reference.bytes > 2 * 1024 * 1024) throw new Error('Evidence file exceeds 2 MiB. Provide a bounded report.');
          const text = await ctx.fs.readText(refTarget, signal);
          if (!text.includes(current.sha256)) throw new Error('Evidence report must contain the final artifact SHA-256 to bind its claims to this version.');
          state.evidence = state.evidence.filter(e => e.level !== args.level);
          state.evidence.push({ level: args.level, note: args.note, reference, targetKey: current.key, sha256: current.sha256, recordedAt: Date.now() });
          result = { recorded: args.level, verification: 'Reviewer-attested; plugin validates reference existence and artifact binding only.' };
        } else if (args.action === 'finish') {
          result = finish(state, await fingerprint(state.target.path, cwd, signal));
          for (const evidence of state.evidence) {
            try {
              const current = await fingerprint(evidence.reference.path, cwd, signal);
              if (current.sha256 !== evidence.reference.sha256 || current.key !== evidence.reference.key) result.missing.push(`${evidence.level}: evidence report changed`);
            } catch { result.missing.push(`${evidence.level}: evidence report unavailable`); }
          }
          result.closed = result.missing.length === 0;
          if (result.closed) state.status = 'closed';
        }
      }
    }
    // Cache is only an acceleration; committed tool/command output is the recovery record.
    signal?.throwIfAborted();
    cache.set(agent.id, { state, cwd });
    return envelope(state, result);
  }
  const execute = (args, agent, signal) => serial(agent.id, () => operate(args, agent, signal));
  const disposeTool = ctx.tools.register({
    name: 'aspen_guardrail', description: 'Plan Aspen file changes, review repeated failures, and track artifact-bound acceptance evidence. Returns a resumable task record; finish checks hashes, not engineering truth.',
    parameters, output: { schema: { type: 'object', additionalProperties: true }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
    execute: (args, exec) => execute(args, exec.agent, exec.signal)
  });
  const disposeCommand = ctx.commands.register({
    name: 'aspen-guardrail', description: 'Aspen 防坑：任务记录、会话复盘和交付证据 / task and evidence review',
    input: { hint: 'JSON, e.g. {"action":"rules"}' },
    handler: async ({ agent, rawInput, signal }) => {
      try { return { kind: 'success', text: JSON.stringify(await execute(JSON.parse(rawInput || '{"action":"rules"}'), agent, signal)) }; }
      catch (error) { return { kind: 'error', text: error.message }; }
    }
  });
  const disposeGuard = ctx.tools.guard(exec => {
    const target = mutationTarget(exec);
    if (!target || !exec.agent?.id) return;
    const record = cache.get(exec.agent.id);
    const state = record?.state;
    const normalize = value => process.platform === 'win32' ? value.toLowerCase() : value;
    if (state?.status === 'active' && normalize(path.resolve(record.cwd, target)) === normalize(path.resolve(state.target.path))) return;
    return 'Aspen Guardrail: start/check an active contract for this exact file before structured write/edit. Shell scripts and external apps are not covered by this gate.';
  });
  ctx.effect(() => () => { disposeGuard(); disposeCommand(); disposeTool(); cache.clear(); queues.clear(); });
}
