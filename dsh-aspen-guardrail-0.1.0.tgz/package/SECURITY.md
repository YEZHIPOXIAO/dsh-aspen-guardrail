# Security

Version 0.1.x is experimental. The structured write/edit gate is a workflow aid, not a security boundary: shell commands, scripts, external applications, symlink changes and other tools are not comprehensively intercepted.

The plugin reads artifacts through Harness filesystem services and uses the current workspace for relative paths. It hashes at most 64 MiB per file and accepts evidence reports up to 2 MiB. It never edits a simulation, installs Python dependencies, launches Aspen, sends telemetry or makes network requests.

Task and evidence metadata are included in the normal session log. They may contain paths and reviewer notes; review exports before sharing. The open-source package contains only synthetic tests.

For vulnerabilities, use the repository owner's GitHub private vulnerability reporting if enabled. Do not post credentials or private models to public issues. Before publishing a repository, its owner must enable private reporting or add a real private contact here. No reporting address is invented in this template.

Evidence references are reviewer attestations. Hash matching does not prove that Aspen was run or that a process is safe. Engineering sign-off remains external.
