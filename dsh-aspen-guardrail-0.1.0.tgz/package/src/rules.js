// SPDX-License-Identifier: MIT
// Curated diagnostic prompts, not universal Aspen API or engineering assertions.
export const rules = [
  { id: 'COM-REGISTRATION', pattern: '80040154|REGDB_E_CLASSNOTREG|Class not registered', title: 'COM registration failure', next: 'Discover installed ProgIDs and interpreter architecture; do not guess a version.', scope: 'com', threshold: 1 },
  { id: 'COM-NODE', pattern: 'IHNode|不能在图标节点|DISP_E_TYPEMISMATCH|type mismatch', title: 'COM binding or signature mismatch', next: 'Inspect the exact method and node shape. Test a minimal read in Python/pywin32 or VBScript before changing a model.', scope: 'com', threshold: 2 },
  { id: 'COM-UNDERSPEC', pattern: 'AE_UNDERSPEC', title: 'Node write rejected', next: 'Confirm input completeness and node writability on a disposable copy; consider validated input-card editing.', scope: 'com', threshold: 2 },
  { id: 'PYTHON-ENV', pattern: "No module named ['\"](?:win32com|pythoncom)|ModuleNotFoundError.*(?:win32com|pythoncom)", title: 'Python COM dependency unavailable', next: 'Probe the exact interpreter. Manage a workspace environment through pyenv tools; do not assume bundled dependencies remain stable.', scope: 'environment', threshold: 1 },
  { id: 'TEXT-DECODE', pattern: 'UnicodeDecodeError|codec can.t decode', title: 'Input decoding failed', next: 'Inspect bytes and encoding; find GRAPHICS_BACKUP and preserve its bytes. Do not use lossy decoding to rewrite the whole file.', scope: 'file', threshold: 1 },
  { id: 'TEXT-ENCODE', pattern: 'UnicodeEncodeError|codec can.t encode', title: 'Output encoding failed', next: 'Check terminal encoding and the actual interpreter, separately from the simulation file encoding.', scope: 'environment', threshold: 1 },
  { id: 'FIT-SINGULAR', pattern: 'SINGULAR HESSIAN|奇异.*HESSIAN', title: 'Regression sensitivity failure', next: 'Review explicit time units, component binding and simulation horizon; several causes are possible.', scope: 'engineering', threshold: 1 },
  { id: 'CONVERGENCE-TEAR', pattern: 'NO.*TEAR.*IS SPECIFIED|NO.*TEAR-TEAR', title: 'Convergence input syntax rejected', next: 'Validate tear-stream syntax with a version-matched example or an Aspen-generated roundtrip on a copy.', scope: 'engineering', threshold: 1 }
];
export const checklist = [
  'Identify the authoritative source, target file and permitted changes.',
  'Probe the exact interpreter and installed COM registration; opening and writability remain untested until explicitly exercised.',
  'For BKP, inspect encoding and preserve GRAPHICS_BACKUP bytes; for APWZ, test archive structure and record which member was verified.',
  'Verify experimental units, component bindings and the final observation time against the simulation horizon.',
  'Distinguish conversion from product purity; do not infer either solely from a number.',
  'Review compression staging, cooling, pressure topology and exchanger specification side using the design basis.',
  'Review phase feasibility using mixture composition and phase equilibrium; a pure-component critical point alone does not decide mixture feasibility.',
  'Keep process changes, warnings and unknowns explicit. A converged calculation is not engineering acceptance.',
  'Verify the final delivery path after edits, with a new hash baseline and fresh reopen/run evidence.'
];
export function matchRules(text) {
  return rules.filter(rule => new RegExp(rule.pattern, 'i').test(text));
}
