// SPDX-License-Identifier: MIT
import { matchRules, checklist } from './rules.js';
export const MARKER = 'aspen-guardrail/v1';
export function restore(events) {
  let state = null;
  const calls = new Map();
  const commands = new Map();
  for (const event of events) {
    if (event.type === 'tool/call') calls.set(event.data.callId, event.data.name);
    if (event.type === 'command/run') commands.set(event.data.commandId, event.data.name);
    let texts = [];
    if (event.type === 'tool/result') {
      const message = event.data?.message;
      if (message?.isError || calls.get(message?.toolCallId) !== 'aspen_guardrail') continue;
      texts = (message?.content ?? []).filter(x => x.type === 'text').map(x => x.text);
    } else if (event.type === 'command/done') {
      if (commands.get(event.data?.commandId) === 'aspen-guardrail' && event.data?.kind === 'success') texts = [event.data.text];
    }
    for (const text of texts) {
      try {
        const value = JSON.parse(text);
        if (value?.marker === MARKER && value.state?.sessionId && value.state?.target?.sha256) state = value.state;
      } catch { /* Other plugin output is not a checkpoint. */ }
    }
  }
  return state;
}
export function review(events) {
  const calls = new Map();
  const groups = new Map();
  let results = 0;
  for (const event of events) {
    if (event.type === 'tool/call') calls.set(event.data.callId, event);
    if (event.type !== 'tool/result') continue;
    const message = event.data?.message;
    const call = calls.get(message?.toolCallId);
    if (!call || call.data.name === 'aspen_guardrail') continue;
    // Never scan assistant prose or read/search output: quoted errors are not new failures.
    if (!/^(ops_bash|bash|pwsh|job_output|terminal_read)$/.test(call.data.name)) continue;
    results++;
    const text = (message.content ?? []).filter(x => x.type === 'text').map(x => x.text).join('\n');
    for (const rule of matchRules(text)) {
      const group = groups.get(rule.id) ?? { ruleId: rule.id, title: rule.title, next: rule.next, threshold: rule.threshold, evidence: [] };
      if (!group.evidence.some(e => e.callId === call.data.callId)) group.evidence.push({ seq: event.seq, callId: call.data.callId, time: event.time });
      groups.set(rule.id, group);
    }
  }
  return { scannedResults: results, findings: [...groups.values()].map(g => ({ ...g, count: g.evidence.length, reconsiderRoute: g.evidence.length >= g.threshold, evidence: g.evidence.slice(-20), confidence: 'candidate: verify event context' })), caveat: 'Candidate signatures, not proven root causes. Job polling can repeat historical output. No time savings are inferred.' };
}
export function newState(sessionId, target, args, now = Date.now()) {
  if (!args.intent?.trim() || !args.route?.trim()) throw new Error('start requires intent and route');
  return { sessionId, status: 'active', target, intent: args.intent, route: args.route, createdAt: now, baseline: null, evidence: [], checklist };
}
export function finish(state, current) {
  const missing = [];
  if (!state.baseline) missing.push('Capture the final artifact with snapshot before collecting acceptance evidence.');
  if (state.baseline && (current.key !== state.baseline.key || current.sha256 !== state.baseline.sha256)) missing.push('Artifact changed after snapshot; take a new snapshot and repeat verification.');
  for (const level of ['V0', 'V1', 'V2', 'V3']) {
    if (!state.evidence.some(e => e.level === level && e.sha256 === current.sha256 && e.targetKey === current.key && e.recordedAt >= (state.baseline?.capturedAt ?? Infinity))) missing.push(`${level}: fresh, artifact-bound evidence required`);
  }
  return { closed: missing.length === 0, missing, assurance: 'Evidence references and file identity checked; engineering assertions are reviewer attestations, not independently simulated.' };
}
export function mutationTarget(exec) {
  if (!['write', 'edit'].includes(exec.name)) return null;
  const target = exec.arguments?.file_path ?? exec.arguments?.path;
  return typeof target === 'string' && /\.(bkp|apw|apwz|inp)$/i.test(target) ? target : null;
}
export function envelope(state, result) { return { marker: MARKER, state, result }; }
export function resumePacket(state) {
  return `# Aspen Guardrail\n\nStatus: ${state.status}\n\nTarget: ${state.target.path}\n\nIntent: ${state.intent}\n\nRoute: ${state.route}\n\nFinal baseline: ${state.baseline?.sha256 ?? 'not captured'}\n\n## Evidence\n\n${state.evidence.map(e => `- ${e.level}: ${e.note} (${e.reference.path})`).join('\n') || '- None'}\n\n## Next step\n\n${state.status === 'closed' ? 'Review residual risks in the evidence records before delivery.' : 'Check the current artifact, resolve review findings, then collect V0–V3 evidence.'}\n`;
}
