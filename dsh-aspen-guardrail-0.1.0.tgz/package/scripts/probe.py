# SPDX-License-Identifier: MIT
"""Read-only environment observation. Never launches Aspen or changes Python packages."""
import hashlib
import importlib.util
import json
import platform
import struct
import sys


def probe():
    data = {
        "schemaVersion": 1,
        "interpreter": sys.executable,
        "pythonVersion": platform.python_version(),
        "architectureBits": struct.calcsize("P") * 8,
        "platform": sys.platform,
        "pywin32": importlib.util.find_spec("win32com") is not None,
        "progIds": [],
        "registrationErrors": [],
        "openBkp": "untested",
        "openApwz": "untested",
        "streamWritable": "untested",
    }
    if sys.platform == "win32":
        import winreg
        for view, flag in (("64", winreg.KEY_WOW64_64KEY), ("32", winreg.KEY_WOW64_32KEY)):
            try:
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, "", 0, winreg.KEY_READ | flag) as root:
                    index = 0
                    while True:
                        try:
                            key = winreg.EnumKey(root, index)
                            index += 1
                        except OSError as exc:
                            if exc.winerror == 259:
                                break
                            raise
                        if key.startswith("Apwn.Document"):
                            data["progIds"].append({"view": view, "progId": key})
            except OSError as exc:
                data["registrationErrors"].append({"view": view, "error": str(exc)})
    data["progIds"].sort(key=lambda x: (x["view"], x["progId"]))
    data["fingerprint"] = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
    return data


if __name__ == "__main__":
    print(json.dumps(probe(), ensure_ascii=True, indent=2))
