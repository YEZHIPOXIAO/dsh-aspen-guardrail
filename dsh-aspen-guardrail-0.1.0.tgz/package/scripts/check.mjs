// SPDX-License-Identifier: MIT
import { readFileSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
for (const file of ['index.js', 'client.js', 'src/core.js', 'src/rules.js']) {
  const run = spawnSync(process.execPath, ['--check', file], { stdio: 'inherit' });
  if (run.status !== 0) process.exit(run.status ?? 1);
}
for (const file of ['./index.js', './client.js', './icon.svg', './cordis.patch.yml', 'README.md', 'LICENSE', 'NOTICE']) {
  if (!existsSync(file)) throw new Error(`Missing distribution resource: ${file}`);
}
for (const language of ['en', 'zh']) {
  const locale = JSON.parse(readFileSync(`locale/${language}.json`, 'utf8'));
  if (!locale.meta?.title || !locale.meta?.description) throw new Error('Missing localized metadata');
}
if (pkg.license !== 'MIT' || pkg.dependencies || pkg.scripts.postinstall) throw new Error('Unexpected license/dependencies/install script');
const icon = readFileSync('icon.svg', 'utf8');
if (!icon.includes('<svg') || icon.includes('<script') || Buffer.byteLength(icon) > 262144) throw new Error('Invalid icon');
console.log('Syntax, manifest and distribution resources verified.');
