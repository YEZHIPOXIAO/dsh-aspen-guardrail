# SPDX-License-Identifier: MIT
"""Package public source, excluding model artifacts and local evidence."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
output = root.parent / "aspen-guardrail-source-0.1.0.zip"
allow = {"package.json", "index.js", "client.js", "cordis.patch.yml", "icon.svg", "LICENSE", "NOTICE", ".gitignore", "README.md", "CONTRIBUTING.md", "SECURITY.md", "CHANGELOG.md", "VERIFICATION.md"}
folders = {"src", "test", "scripts", "locale", ".github"}
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
    for item in sorted(root.rglob("*")):
        if not item.is_file() or item.is_symlink():
            continue
        rel = item.relative_to(root)
        if "__pycache__" in rel.parts:
            continue
        if str(rel) in allow or rel.parts[0] in folders:
            archive.write(item, "aspen-guardrail/" + rel.as_posix())
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert "aspen-guardrail/.github/workflows/ci.yml" in archive.namelist()
    print(f"Verified source archive: {len(archive.namelist())} files")
print(output)
