// SPDX-License-Identifier: MIT
window.__ModuleLoader__.load({
  id: 'dsh-aspen-guardrail',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        const dictionaries = {
          en: { title: 'Aspen Guardrail · usage', intro: 'Use the slash command below or ask the agent to call aspen_guardrail. Results are recorded in this session.', flow: 'start → edit → snapshot → evidence V0–V3 → finish', scope: 'The gate covers structured write/edit only. Shell scripts are not intercepted. Evidence records are attestations, not independent Aspen runs.', rules: 'Show rules', review: 'Review this session' },
          zh: { title: 'Aspen 防坑助手 · 使用说明', intro: '在输入框使用以下命令，或让助手调用 aspen_guardrail。结果会记录在当前会话。', flow: 'start 建立任务 → 修改 → snapshot 最终指纹 → evidence V0–V3 → finish 验收', scope: '拦截范围仅为结构化 write/edit；不拦截 Shell 脚本。证据记录属于声明与引用核验，不等于独立运行 Aspen。', rules: '查看规则', review: '复盘当前会话' }
        };
        for (const [language, dict] of Object.entries(dictionaries)) ctx.locale.register('aspenGuardrail', language, dict);
        const t = ctx.locale.bind('aspenGuardrail');
        function Panel() {
          React.useSyncExternalStore(fn => ctx.locale.subscribe(fn), () => ctx.locale.getSnapshot());
          return h('details', { style: { color: 'var(--dsw-alias-label-secondary)', fontSize: 12, padding: '6px 10px', border: '1px solid var(--dsw-alias-border-l1)', borderRadius: 8, background: 'var(--dsw-alias-bg-layer-1)', overflowWrap: 'anywhere' } },
            h('summary', { style: { cursor: 'pointer', color: 'var(--dsw-alias-label-primary)' } }, t('title')),
            h('p', null, t('intro')), h('p', null, t('flow')),
            h('p', null, t('rules'), ': ', h('code', null, '/aspen-guardrail {"action":"rules"}')),
            h('p', null, t('review'), ': ', h('code', null, '/aspen-guardrail {"action":"review"}')),
            h('p', null, t('scope')));
        }
        ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register({ name: 'conversation.composer.dock', id: 'aspen-guardrail-help', order: 20, label: () => t('title') }, Panel));
      }
    };
  }
});
