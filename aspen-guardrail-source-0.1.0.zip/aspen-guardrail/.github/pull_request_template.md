## Problem and change

## Evidence and tests

## Compatibility and limitations

- [ ] Added synthetic positive/negative fixtures where behavior changes
- [ ] No private logs, models, credentials or machine-specific paths included
- [ ] Documented any new interception or persistence behavior
