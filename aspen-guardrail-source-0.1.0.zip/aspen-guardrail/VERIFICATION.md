# Verification record — 0.1.0

Verified locally on 2026-10-27 against Harness 0.2.1-rc.3 on Windows.

- Seven Node tests passed: missing final baseline, stale artifact, missing verification level, log checkpoint provenance, quoted-error exclusion, structured gate scope, shared tool/command flow, recovery and changed-report rejection (some tests cover multiple assertions).
- JavaScript syntax, package resource presence and bilingual metadata checks passed.
- Plugin Manager returned `application: applied`, version 0.1.0, no bundle warnings. The package resolver printed an existing profile peer-dependency warning; this plugin declares no dependencies.
- Live Client slot inspection confirmed `aspen-guardrail-help` active under `conversation.composer.dock`.
- Live Agent tool reviewed a same-workspace historical session and returned event-linked diagnostic candidates.
- Live start/snapshot/finish cycle hashed an existing artifact without edits. finish returned `closed:false` for missing V0–V3. The temporary contract was cancelled.
- Read-only Python probe ran successfully: interpreter and COM registry information returned; Aspen opening/writability stayed `untested`.
- Local installation is a symlink to the source checkout. The installed resources are the checked source files. No default/template artwork is intentionally used.
- `pnpm pack` listed only intended runtime files, scripts, synthetic tests and public documentation.

## Not verified

- Actual browser rendering, light/dark appearance, icon rendering and user click flow: no authenticated browser-control tool was available. Slot registration is not visual acceptance.
- Slash command execution through the real browser: shared handler behavior is tested in the adapter test, but live UI interaction was not exercised.
- Real Aspen engine runs or engineering accuracy. All acceptance assertions remain reviewer attestations.
- Cross-platform CI execution: workflow supplied; GitHub has not run it because no repository has been published.
- No numerical time-savings claim, exhaustive shell interception, automatic route switching, or production security guarantee.
